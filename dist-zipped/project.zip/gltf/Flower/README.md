# Flower

Model by [Kenney](https://twitter.com/KenneyNL), from [Nature Pack](https://www.kenney.nl/assets/nature-pack). CC0 1.0.

Modifications by [Don McCurdy](https://donmccurdy.com/):

- Split stem and blossom meshes.
- Color adjustments.
