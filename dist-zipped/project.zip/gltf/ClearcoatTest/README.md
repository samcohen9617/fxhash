# Clearcoat Test

This model tests various settings and textures from the KHR_materials_clearcoat extension. Original version and further details in [glTF-Sample-Models / 2.0 / ClearcoatTest](https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/ClearCoatTest).

## License Information

Copyright 2020 Analytical Graphics, Inc. [CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/). Model and textures by Ed Mackey.
