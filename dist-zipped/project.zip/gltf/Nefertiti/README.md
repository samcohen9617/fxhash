# Nefertiti

## License Information

Model is provided under a creative commons license for non-commercial purposes (CC BY-NC).

3D scan of a copy of the Nefertiti Bust

Digitized by Fraunhofer IGD, Competence Center Cultural Heritage Digitization, http://www.cultlab3d.de/
